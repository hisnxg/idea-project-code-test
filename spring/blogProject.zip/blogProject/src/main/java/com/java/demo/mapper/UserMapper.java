package com.java.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.java.demo.domain.User;

public interface UserMapper extends BaseMapper<User> {

}
